package interfaces;

public interface RequireDataService {
  public void bindDataService(DataService service);
}