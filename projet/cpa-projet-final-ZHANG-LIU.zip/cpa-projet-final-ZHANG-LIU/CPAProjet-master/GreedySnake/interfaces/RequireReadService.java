package interfaces;


public interface RequireReadService {
    public void bindReadService(ReadService service);
}
