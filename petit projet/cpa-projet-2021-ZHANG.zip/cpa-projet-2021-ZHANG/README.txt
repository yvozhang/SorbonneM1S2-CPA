1.Le fichier <input.points> est le fichier de test d'entrée utilisé pour visualiser le cercle minimum.

2.Le répertoire <petitProjet> est un project Java, il contient un répertoire <sample> de taille 1664 comme base de test, et quand vous exécutez la class Main, il va écrirer le résultat dans le fichier résultat.txt.

3.Entrer 'java -jar petitProjet.jar' dans le console pour exécuter le projet.