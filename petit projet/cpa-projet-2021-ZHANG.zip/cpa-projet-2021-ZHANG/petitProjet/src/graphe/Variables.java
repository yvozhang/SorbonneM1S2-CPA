package graphe;

public class Variables {
	public static final String MAINPANEL = "1664";
	public static final Object lock = new Object();
	public static final Object lock2 = new Object();
}
